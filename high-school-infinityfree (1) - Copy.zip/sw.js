// বই/ডেটা বদলালে VERSION সংখ্যা বাড়ান, তাহলে ব্যবহারকারীরা নতুন ডেটা পাবে
var VERSION="hs-v1";
var FILES=["./","index.html","css/style.css","js/app.js","data/data.js","manifest.json","icons/icon-192.png","icons/icon-512.png"];
self.addEventListener("install",function(e){e.waitUntil(caches.open(VERSION).then(function(c){return Promise.all(FILES.map(function(f){return c.add(f).catch(function(){})}))}));self.skipWaiting()});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(n){return n!==VERSION}).map(function(n){return caches.delete(n)}))}));self.clients.claim()});
self.addEventListener("fetch",function(e){if(e.request.method!=="GET")return;
e.respondWith(fetch(e.request).then(function(r){var c=r.clone();if(r.ok&&e.request.url.indexOf(location.origin)===0)caches.open(VERSION).then(function(x){x.put(e.request,c)});return r}).catch(function(){return caches.match(e.request).then(function(m){return m||caches.match("index.html")})}))});
