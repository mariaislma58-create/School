var bn="০১২৩৪৫৬৭৮৯",N=function(n){return String(n).replace(/\d/g,function(d){return bn[d]})};
var cls=0,tab=1,$=function(i){return document.getElementById(i)};
var chips=$("chips");
[0,6,7,8,9,10].forEach(function(c){var b=document.createElement("button");b.className="chip";b.textContent=c?N(c)+" শ্রেণি":"সব শ্রেণি";b.setAttribute("aria-pressed",c===cls);b.onclick=function(){cls=c;[].forEach.call(chips.children,function(x){x.setAttribute("aria-pressed",x===b)});render()};chips.appendChild(b)});
function esc(s){return s.replace(/[&<>]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;"}[c]})}
function hl(s,k){s=esc(s);if(!k)return s;var i=s.toLowerCase().indexOf(k);return i<0?s:s.slice(0,i)+"<mark>"+s.slice(i,i+k.length)+"</mark>"+s.slice(i+k.length)}
function render(){
var k=$("q").value.trim().toLowerCase(),h="";
D.forEach(function(d){
if(cls&&d.c!==cls)return;
var head=d.s+" "+d.ch,hit=head.toLowerCase().indexOf(k)>=0;
var items=(tab===1?d.q:d.m).filter(function(x){return !k||hit||x[0].toLowerCase().indexOf(k)>=0||(tab===1&&x[1].toLowerCase().indexOf(k)>=0)});
if(!items.length)return;
h+='<div class="ch">'+N(d.c)+' শ্রেণি · '+esc(d.s)+' · <b>'+esc(d.ch)+'</b></div>';
items.forEach(function(x,i){
if(tab===1)h+='<details><summary>'+hl(x[0],k)+'</summary><p>'+hl(x[1],k)+'</p></details>';
else{h+='<div class="mcq" data-a="'+x[2]+'"><div>'+hl(x[0],k)+'</div>';x[1].forEach(function(o,j){h+='<button class="opt" data-j="'+j+'">'+esc(o)+'</button>'});h+='</div>'}
})});
$("out").innerHTML=h||'<div class="empty">কিছু পাওয়া যায়নি। অন্য শব্দ দিয়ে খুঁজুন বা শ্রেণি বদলান।</div>'}
$("out").onclick=function(e){var b=e.target.closest(".opt");if(!b)return;var m=b.parentNode,a=+m.dataset.a;if(m.dataset.done)return;m.dataset.done=1;
[].forEach.call(m.querySelectorAll(".opt"),function(o){if(+o.dataset.j===a)o.classList.add("right")});
if(+b.dataset.j!==a)b.classList.add("wrong")};
function setTab(n){tab=n;$("t1").setAttribute("aria-selected",n===1);$("t2").setAttribute("aria-selected",n===2);render()}
$("t1").onclick=function(){setTab(1)};$("t2").onclick=function(){setTab(2)};
$("q").oninput=render;render();
